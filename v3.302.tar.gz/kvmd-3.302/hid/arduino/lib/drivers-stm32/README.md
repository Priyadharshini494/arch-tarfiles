This is WIP. Use AVR version as reference.

It was tested with bluepill. Most boards are clones.
If you have problem with USB please check https://stm32duinoforum.com/forum/wiki_subdomain/index_title_Blue_Pill.html for pull up resistor. If it still does not work check another board or cable.

TODO:
- [x] Serial communication
- [x] USB keyboard
- [x] USB keyboard - add scroll status
- [x] USB keyboard - key sending
- [x] USB keyboard - test key mapping
- [x] Persistent storage
- [ ] SPI communication
- [ ] PS2 keyboard
- [x] USB absolute mouse
- [x] USB absolute mouse - add whele
- [x] USB relative mouse
- [x] USB relative mouse - add whele
- [ ] USB mouses - up down button
- [ ] WIN98 USB mouse
- [x] undefine SERIAL_USB
- [ ] boot keyboard
